# mini_calc

Generated project.
